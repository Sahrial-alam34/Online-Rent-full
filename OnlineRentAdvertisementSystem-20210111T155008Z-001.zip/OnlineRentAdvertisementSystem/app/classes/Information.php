<?php

namespace App\classes;


class Information
{
    public function GetUserInfo()
    {
        $link = mysqli_connect("localhost", "root", "", "rentdb");
        $sql = "Select * from users ";
        // mysqli_query($link, $sql);
        if (mysqli_query($link, $sql)) {
            $query_result = mysqli_query($link, $sql);
            return $query_result;

        } else {
            die('Query problem' . mysqli_error($link));
        }
    }
    public function deleteUserInfo($user_id)
    {
        $link = mysqli_connect("localhost", "root", "", "rentdb");
        $sql = "delete from users WHERE user_id='$user_id'";
        // mysqli_query($link, $sql);
        if (mysqli_query($link, $sql)) {
            header('Location: Admin_Show_User.php');//location

        } else {
            die('Query problem'.mysqli_error($link));
        }
        
    }
    public function createAdvertise($information)
    {
       // echo'<pre>';
        //print_r($information);
        $link = mysqli_connect("localhost", "root", "", "rentdb");
        $sql = "insert into advertisements (Rent_type,Rent_name,U_district,U_city,U_area,U_amount,U_gmail,U_phone,U_Trx_id,image1,image2,image3,image4,image5,image6,A_date,D_date,comment) value( '$information[Rent_type]','$information[Rent_name]','$information[U_district]','$information[U_city]','$information[U_area]','$information[U_amount]','$information[U_gmail]','$information[U_phone]','$information[U_Trx_id]','$information[image1]','$information[image2]','$information[image3]','$information[image4]','$information[image5]','$information[image6]','$information[A_date]','$information[D_date]','$information[comment]')";
        if (mysqli_query($link, $sql)) {
            echo 'success';

        } else {
            die('Query problem'.mysqli_error($link));
        }

    }

    public function GetAdvertiseInfo()
    {
        $link = mysqli_connect("localhost", "root", "", "rentdb");
        $sql = "Select * from advertisements ";
        // mysqli_query($link, $sql);
        if (mysqli_query($link, $sql)) {
            $query_result = mysqli_query($link, $sql);
            return $query_result;

        } else {
            die('Query problem' . mysqli_error($link));
        }
    }

    public function GetImage($image1)
    {
        $link = mysqli_connect("localhost", "root", "", "rentdb");
        $sql = "Select * from advertisements WHERE image1='$image1'AND Add_id='1'";
        // mysqli_query($link, $sql);
        if (mysqli_query($link, $sql)) {
            $Reveive_query_result = mysqli_query($link, $sql);
            return $Reveive_query_result;

        } else {
            die('Query problem' . mysqli_error($link));
        }
    }

    public function deleteAdvertiseInfo($Add_id)
    {
        $link = mysqli_connect("localhost", "root", "", "rentdb");
        $sql = "delete from advertisements WHERE Add_id='$Add_id'";
        // mysqli_query($link, $sql);
        if (mysqli_query($link, $sql)) {
            header('Location: Admin_Show_Ad.php');//location

        } else {
            die('Query problem'.mysqli_error($link));
        }

    }

    public function createApproveAdvertise($information)
    {
        // echo'<pre>';
        //print_r($information);
        $link = mysqli_connect("localhost", "root", "", "rentdb");
        $sql = "insert into approve_advertisements (Rent_type,Rent_name,U_district,U_city,U_area,U_amount,U_gmail,U_phone,U_Trx_id,image1,image2,image3,image4,image5,image6,A_date,D_date,comment) value( '$information[Rent_type]','$information[Rent_name]','$information[U_district]','$information[U_city]','$information[U_area]','$information[U_amount]','$information[U_gmail]','$information[U_phone]','$information[U_Trx_id]','$information[image1]','$information[image2]','$information[image3]','$information[image4]','$information[image5]','$information[image6]','$information[A_date]','$information[D_date]','$information[comment]')";
        if (mysqli_query($link, $sql)) {
            header('Location: Admin_Show_Ad.php');//locatio

        } else {
            die('Query problem'.mysqli_error($link));
        }

    }


}